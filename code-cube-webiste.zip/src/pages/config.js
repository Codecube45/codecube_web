export const config = {
    appUrl:"/"
}