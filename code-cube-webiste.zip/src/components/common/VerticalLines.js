import React from "react";

const VerticalLines = () => {
  return (
    <div>
      <div class="container-fluid">
        <div class="item-efftect container">
          <div class="efftect overflow-hidden"></div>
          <div class="efftect overflow-hidden"></div>
          <div class="efftect overflow-hidden"></div>
          <div class="efftect overflow-hidden"></div>
          <div class="efftect overflow-hidden"></div>
        </div>
      </div>
    </div>
  );
};

export default VerticalLines;
